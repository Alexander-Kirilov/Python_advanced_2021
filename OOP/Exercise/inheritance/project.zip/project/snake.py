from project.lizard import Lizard


class Snake(Lizard):
    pass

    @property
    def name(self):
        return self.__name
