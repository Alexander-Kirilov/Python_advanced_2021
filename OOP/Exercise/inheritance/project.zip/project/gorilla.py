from project.mammal import Mammal


class Gorilla(Mammal):
    pass

    @property
    def name(self):
        return self.__name
