from project.mammal import Mammal


class Bear(Mammal):
    pass

    @property
    def name(self):
        return self.__name
