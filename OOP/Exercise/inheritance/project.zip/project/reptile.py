from project.animal import Animal


class Reptile(Animal):
    pass

    @property
    def name(self):
        return self.__name