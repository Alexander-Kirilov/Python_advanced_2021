from project.reptile import Reptile


class Lizard(Reptile):
    pass

    @property
    def name(self):
        return self.__name