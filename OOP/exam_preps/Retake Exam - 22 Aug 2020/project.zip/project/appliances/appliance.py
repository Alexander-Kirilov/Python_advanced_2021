class Appliance:
    _DAYS_IN_MONTH = 30

    def __init__(self, cost):
        self.cost = cost

    def get_monthly_expenses(self):
        return self.cost * Appliance._DAYS_IN_MONTH
