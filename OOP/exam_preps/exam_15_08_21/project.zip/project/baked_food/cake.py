from project.baked_food.baked_food import BakedFood

from abc import ABC, abstractmethod


class Cake(BakedFood, ABC):

    @abstractmethod
    def __init__(self, name, price):
        super().__init__(name, price)
        self.portion = 245
