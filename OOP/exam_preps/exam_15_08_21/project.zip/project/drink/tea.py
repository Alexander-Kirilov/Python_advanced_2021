from abc import ABC, abstractmethod

from project.drink.drink import Drink


class Tea(Drink, ABC):

    @abstractmethod
    def __init__(self, name, portion, brand):
        super().__init__(name, portion, brand)
        self.price = 2.50
