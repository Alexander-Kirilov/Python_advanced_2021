from abc import ABC, abstractmethod

from project.drink.drink import Drink


class Water(Drink, ABC):

    @abstractmethod
    def __init__(self, name, portion, brand):
        super().__init__(name, portion, brand)
        self.price = 1.50
