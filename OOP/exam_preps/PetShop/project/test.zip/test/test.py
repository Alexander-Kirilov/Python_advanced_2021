from project.pet_shop import PetShop
from unittest import TestCase, main


class TestPetShop(TestCase):
    def setUp(self) -> None:
        self.ps = PetShop("test")

    def test_pet_shop_init(self):
        self.assertEqual("test", self.ps.name)
        self.assertEqual({}, self.ps.food)
        self.assertEqual([], self.ps.pets)

    def test_add_food_with_quantity_less_than_zero_raises(self):
        with self.assertRaises(ValueError) as ex:
            self.ps.add_food("test_food", -1)
        self.assertEqual('Quantity cannot be equal to or less than 0', str(ex.exception))

    def test_add_food_ok(self):
        self.ps.add_food("test_food", 2)
        self.assertEqual({"test_food": 2}, self.ps.food)

    def test_add_food_with_ok_quantity(self):
        self.assertEqual(f"Successfully added 3.00 grams of test_food.", self.ps.add_food("test_food", 3))
        self.assertEqual(f"Successfully added 2.00 grams of test_food.", self.ps.add_food("test_food", 2))
        self.assertEqual({"test_food": 5}, self.ps.food)

    def test_add_food_two_names(self):
        self.ps.add_food("test_food_1", 1)
        self.ps.add_food("test_food_2", 2)
        self.assertEqual({"test_food_1": 1, "test_food_2": 2}, self.ps.food)

    def test_add_pet_with_ok_name(self):
        self.ps.add_pet("test_pet")
        self.assertEqual(["test_pet"], self.ps.pets)
        self.ps.add_pet("test_pet_2")
        self.assertEqual(["test_pet", "test_pet_2"], self.ps.pets)

    def test_add_pet_with_same_name_raises(self):
        self.ps.add_pet("test")
        with self.assertRaises(Exception) as ex:
            self.ps.add_pet("test")
        self.assertEqual("Cannot add a pet with the same name", str(ex.exception))

    def test_feed_pet(self):
        self.ps.add_pet("test")
        self.ps.feed_pet("test")
        self.assertEqual("test was successfully fed", self.ps.feed_pet("test"))



if __name__ == "__main__":
    main()
